# Pixel display font

Silkscreen Regular by Jason Kottke, from Google Fonts.
Source: https://github.com/google/fonts/tree/main/ofl/silkscreen
Local font: `Silkscreen-Regular.ttf`. License: SIL Open Font License, see `OFL.txt`.
Used for English game interface headings and labels; readable sans serif remains for Korean and body text.
