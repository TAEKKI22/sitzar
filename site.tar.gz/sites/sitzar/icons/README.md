# Platform icons

SVG brand marks downloaded from [Simple Icons](https://github.com/simple-icons/simple-icons), whose icon files are distributed under CC0. Brand marks remain the property of their owners.

- [Instagram](https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/instagram.svg)
- [Spotify](https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/spotify.svg)
- [TIDAL](https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/tidal.svg)
- [YouTube](https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/youtube.svg)

The marks link directly to the user-provided music and social pages.
